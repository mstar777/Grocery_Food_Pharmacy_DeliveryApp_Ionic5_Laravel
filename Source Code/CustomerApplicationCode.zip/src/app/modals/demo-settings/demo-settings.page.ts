import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-demo-settings',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './demo-settings.page.html',
  styleUrls: ['./demo-settings.page.scss'],
})


export class DemoSettingsPage implements OnInit {
  
  constructor() {
  }
  ngOnInit() {
  }
}
